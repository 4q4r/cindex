import { useState, useCallback, useMemo, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight, Check } from 'lucide-react';
import { Header } from './components/Header';
import { SearchBar } from './components/SearchBar';
import { FilterPanel } from './components/FilterPanel';
import { InfoBar } from './components/InfoBar';
import { ResultCard } from './components/ResultCard';
import { EmptyState } from './components/EmptyState';
import { LoadingState } from './components/LoadingState';
import { simulateSearch } from './data/mockData';
import { Filters, SearchResult, SearchState, ViewMode, DEFAULT_FILTERS, ALL_SOURCES } from './types';

const PER_PAGE = 5;

export default function App() {
  const [searchState, setSearchState] = useState<SearchState>('idle');
  const [query, setQuery] = useState('');
  const [lastQuery, setLastQuery] = useState('');
  const [filters, setFilters] = useState<Filters>({ ...DEFAULT_FILTERS });
  const [rawResults, setRawResults] = useState<SearchResult[]>([]);
  const [totalBeforeFilter, setTotalBeforeFilter] = useState(0);
  const [filteredOutCount, setFilteredOutCount] = useState(0);
  const [sourcesQueried, setSourcesQueried] = useState(23);
  const [sourcesFailed, setSourcesFailed] = useState<string[]>([]);
  const [lastSearchTime, setLastSearchTime] = useState<Date | null>(null);
  const [viewMode, setViewMode] = useState<ViewMode>('comfortable');
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [copyNotification, setCopyNotification] = useState<string | null>(null);
  const notifTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Apply filters to raw results
  const filteredResults = useMemo(() => {
    let results = [...rawResults];

    // Source filter
    if (filters.sources.length < ALL_SOURCES.length) {
      results = results.filter(r => filters.sources.includes(r.source));
    }

    // Strict filters
    if (filters.doiOnly) results = results.filter(r => r.hasDoi);
    if (filters.peerReviewedOnly) results = results.filter(r => r.isPeerReviewed);
    if (filters.indexedOnly) results = results.filter(r => r.isIndexed);
    if (filters.excludePreprints) results = results.filter(r => !r.isPreprint);

    // Date range
    if (filters.dateFrom) {
      const from = parseInt(filters.dateFrom);
      if (!isNaN(from)) results = results.filter(r => r.year >= from);
    }
    if (filters.dateTo) {
      const to = parseInt(filters.dateTo);
      if (!isNaN(to)) results = results.filter(r => r.year <= to);
    }

    // Sort
    switch (filters.sortBy) {
      case 'newest':
        results.sort((a, b) => b.year - a.year || b.relevanceScore - a.relevanceScore);
        break;
      case 'metadata':
        results.sort((a, b) => {
          const scoreA = (a.hasDoi ? 1 : 0) + (a.isPeerReviewed ? 1 : 0) + (a.isIndexed ? 1 : 0) + (a.doi ? 1 : 0) + (a.pmid ? 1 : 0);
          const scoreB = (b.hasDoi ? 1 : 0) + (b.isPeerReviewed ? 1 : 0) + (b.isIndexed ? 1 : 0) + (b.doi ? 1 : 0) + (b.pmid ? 1 : 0);
          return scoreB - scoreA;
        });
        break;
      case 'relevance':
      default:
        results.sort((a, b) => b.relevanceScore - a.relevanceScore);
        break;
    }

    return results;
  }, [rawResults, filters]);

  // Count how many were filtered out
  useEffect(() => {
    setFilteredOutCount(totalBeforeFilter - filteredResults.length);
  }, [filteredResults.length, totalBeforeFilter]);

  // Pagination
  const totalPages = Math.ceil(filteredResults.length / PER_PAGE);
  const paginatedResults = useMemo(() => {
    const start = (currentPage - 1) * PER_PAGE;
    return filteredResults.slice(start, start + PER_PAGE);
  }, [filteredResults, currentPage]);

  // Reset page when results change
  useEffect(() => {
    setCurrentPage(1);
  }, [rawResults]);

  // Check if any non-default filters are active
  const hasActiveFilters = useMemo(() => {
    return (
      filters.sources.length < ALL_SOURCES.length ||
      filters.doiOnly ||
      filters.peerReviewedOnly ||
      filters.indexedOnly ||
      filters.excludePreprints ||
      filters.dateFrom !== '' ||
      filters.dateTo !== '' ||
      filters.sortBy !== 'relevance'
    );
  }, [filters]);

  const handleSearch = useCallback(async (searchQuery?: string) => {
    const q = searchQuery || query;
    if (!q.trim()) return;

    setLastQuery(q);
    setSearchState('loading');
    setCurrentPage(1);

    try {
      const response = await simulateSearch(q);
      setRawResults(response.results);
      setTotalBeforeFilter(response.totalBeforeFilter);
      setSourcesQueried(response.sourcesQueried);
      setSourcesFailed(response.sourcesFailed);
      setLastSearchTime(new Date());

      if (response.results.length === 0) {
        if (response.sourcesFailed.length > 0) {
          setSearchState('partial');
        } else {
          setSearchState('empty');
        }
      } else if (response.sourcesFailed.length > 0) {
        setSearchState('partial');
      } else {
        setSearchState('results');
      }
    } catch {
      setSearchState('error');
    }
  }, [query]);

  const handleCopy = useCallback(async (text: string, type: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopyNotification(`${type.charAt(0).toUpperCase() + type.slice(1)} copied`);
      if (notifTimeoutRef.current) clearTimeout(notifTimeoutRef.current);
      notifTimeoutRef.current = setTimeout(() => setCopyNotification(null), 2000);
    } catch {
      // Fallback
      const textarea = document.createElement('textarea');
      textarea.value = text;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      setCopyNotification(`${type.charAt(0).toUpperCase() + type.slice(1)} copied`);
      if (notifTimeoutRef.current) clearTimeout(notifTimeoutRef.current);
      notifTimeoutRef.current = setTimeout(() => setCopyNotification(null), 2000);
    }
  }, []);

  const handleClearFilters = useCallback(() => {
    setFilters({ ...DEFAULT_FILTERS });
  }, []);

  const handleExampleClick = useCallback((q: string) => {
    setQuery(q);
    setTimeout(() => handleSearch(q), 0);
  }, [handleSearch]);

  const showResults = searchState === 'results' || (searchState === 'partial' && filteredResults.length > 0);

  return (
    <div className="min-h-screen bg-bg-primary">
      <Header
        resultCount={filteredResults.length}
        lastSearchTime={lastSearchTime}
        sourcesQueried={sourcesQueried}
        sourcesFailed={sourcesFailed}
        searchState={searchState}
      />

      <SearchBar
        query={query}
        onQueryChange={setQuery}
        onSearch={() => handleSearch()}
        isLoading={searchState === 'loading'}
      />

      <div className="max-w-[1440px] mx-auto px-6 py-6">
        <div className="flex gap-8">
          {/* Desktop Filter Panel */}
          <FilterPanel
            filters={filters}
            onFiltersChange={setFilters}
            isMobileOpen={mobileFiltersOpen}
            onMobileClose={() => setMobileFiltersOpen(false)}
          />

          {/* Main content */}
          <div className="flex-1 min-w-0">
            {/* Info bar */}
            {showResults && (
              <div className="mb-5">
                <InfoBar
                  totalResults={filteredResults.length}
                  filteredOut={filteredOutCount}
                  sourcesFailed={sourcesFailed}
                  onClearFilters={handleClearFilters}
                  onToggleMobileFilters={() => setMobileFiltersOpen(true)}
                  viewMode={viewMode}
                  onViewModeChange={setViewMode}
                  hasActiveFilters={hasActiveFilters}
                />
              </div>
            )}

            {/* Partial failure warning */}
            {searchState === 'partial' && filteredResults.length > 0 && (
              <div className="mb-5 flex items-center gap-2 bg-warning-muted/20 border border-warning/20 rounded-lg px-4 py-2.5 text-xs text-warning">
                <span>⚠ Partial results: some sources unavailable ({sourcesFailed.join(', ')}). Showing available results.</span>
              </div>
            )}

            {/* Loading */}
            {searchState === 'loading' && (
              <LoadingState sourcesQueried={sourcesQueried} />
            )}

            {/* Results */}
            {showResults && (
              <div className="space-y-5">
                {paginatedResults.map((result, index) => (
                  <div key={result.id} style={{ animationDelay: `${index * 60}ms` }}>
                    <ResultCard
                      result={result}
                      query={lastQuery}
                      viewMode={viewMode}
                      citationStyle={filters.citationStyle}
                      onCopy={handleCopy}
                    />
                  </div>
                ))}

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="flex items-center justify-center gap-2 pt-6 pb-2">
                    <button
                      onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                      disabled={currentPage === 1}
                      className="flex items-center gap-1 px-3 py-2 text-xs text-text-secondary hover:text-text-primary bg-bg-elevated border border-border-default rounded-lg disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                    >
                      <ChevronLeft className="w-4 h-4" />
                      Previous
                    </button>
                    <div className="flex items-center gap-1">
                      {Array.from({ length: totalPages }, (_, i) => i + 1)
                        .filter(page => {
                          // Show first, last, and pages around current
                          if (page === 1 || page === totalPages) return true;
                          if (Math.abs(page - currentPage) <= 1) return true;
                          return false;
                        })
                        .map((page, idx, arr) => {
                          const prevPage = arr[idx - 1];
                          const showEllipsis = prevPage && page - prevPage > 1;
                          return (
                            <span key={page} className="flex items-center">
                              {showEllipsis && (
                                <span className="px-2 text-text-tertiary text-xs">...</span>
                              )}
                              <button
                                onClick={() => setCurrentPage(page)}
                                className={`w-9 h-9 rounded-lg text-xs font-medium transition-colors ${
                                  page === currentPage
                                    ? 'bg-accent text-white'
                                    : 'text-text-secondary hover:bg-bg-hover hover:text-text-primary'
                                }`}
                              >
                                {page}
                              </button>
                            </span>
                          );
                        })}
                    </div>
                    <button
                      onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                      disabled={currentPage === totalPages}
                      className="flex items-center gap-1 px-3 py-2 text-xs text-text-secondary hover:text-text-primary bg-bg-elevated border border-border-default rounded-lg disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                    >
                      Next
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Empty states */}
            {(searchState === 'idle' || searchState === 'empty' || searchState === 'error' ||
              (searchState === 'partial' && filteredResults.length === 0)) && (
              <EmptyState
                state={searchState}
                onRetry={() => handleSearch()}
                onExampleClick={handleExampleClick}
                sourcesFailed={sourcesFailed}
              />
            )}
          </div>
        </div>
      </div>

      {/* Copy notification toast */}
      {copyNotification && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2 bg-bg-card border border-success/30 text-success px-4 py-2.5 rounded-lg shadow-xl animate-fade-in">
          <Check className="w-4 h-4" />
          <span className="text-sm">{copyNotification}</span>
        </div>
      )}
    </div>
  );
}
