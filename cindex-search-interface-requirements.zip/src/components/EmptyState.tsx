import { BookOpen, Search, AlertCircle, RefreshCw, ArrowRight } from 'lucide-react';
import { SearchState } from '../types';

interface EmptyStateProps {
  state: SearchState;
  onRetry: () => void;
  onExampleClick: (query: string) => void;
  sourcesFailed: string[];
}

const exampleQueries = [
  { query: 'deep learning medical imaging', description: 'Find papers on AI-assisted medical image analysis' },
  { query: 'CRISPR Huntington', description: 'Search for CRISPR applications in Huntington disease research' },
  { query: 'ocean acidification coral reef', description: 'Explore research on marine ecosystem impacts' },
  { query: 'quantum error correction superconducting', description: 'Investigate quantum computing error correction methods' },
  { query: 'antibiotic resistance agriculture', description: 'Review studies on antibiotic resistance in farming' },
  { query: 'машинное обучение прогнозирование', description: 'Поиск русскоязычных публикаций по ML' },
];

export function EmptyState({ state, onRetry, onExampleClick, sourcesFailed }: EmptyStateProps) {
  if (state === 'idle') {
    return (
      <div className="flex flex-col items-center justify-center py-20 px-4 animate-fade-in">
        <div className="max-w-lg w-full text-center">
          <div className="w-16 h-16 mx-auto mb-6 rounded-2xl bg-accent-subtle/30 flex items-center justify-center">
            <BookOpen className="w-8 h-8 text-accent/70" />
          </div>
          <h2 className="text-xl font-semibold text-text-primary mb-3">
            Citation Source Search
          </h2>
          <p className="text-sm text-text-secondary mb-8 leading-relaxed max-w-md mx-auto">
            Search across 23 academic sources for scholarly articles. View peer-reviewed status, 
            indexing confirmation, and generate citations in GOST format.
          </p>
          <div className="text-left space-y-3">
            <h3 className="text-[11px] uppercase tracking-wider text-text-tertiary text-center mb-4">Example searches</h3>
            {exampleQueries.map((ex) => (
              <button
                key={ex.query}
                onClick={() => onExampleClick(ex.query)}
                className="w-full group flex items-center gap-3 bg-bg-card border border-border-default rounded-lg p-3.5 hover:border-accent/30 hover:bg-bg-elevated transition-all text-left"
              >
                <Search className="w-4 h-4 text-text-tertiary group-hover:text-accent transition-colors shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="text-sm text-text-primary font-medium">{ex.query}</div>
                  <div className="text-[11px] text-text-tertiary">{ex.description}</div>
                </div>
                <ArrowRight className="w-4 h-4 text-text-tertiary opacity-0 group-hover:opacity-100 group-hover:text-accent transition-all shrink-0" />
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (state === 'empty') {
    return (
      <div className="flex flex-col items-center justify-center py-20 px-4 animate-fade-in">
        <div className="max-w-md text-center">
          <div className="w-14 h-14 mx-auto mb-5 rounded-2xl bg-bg-elevated flex items-center justify-center">
            <Search className="w-7 h-7 text-text-tertiary" />
          </div>
          <h2 className="text-lg font-semibold text-text-primary mb-2">No results found</h2>
          <p className="text-sm text-text-secondary mb-6 leading-relaxed">
            Try adjusting your search query or removing some filters.
          </p>
          <div className="text-left bg-bg-card border border-border-default rounded-lg p-4 space-y-2">
            <h3 className="text-[11px] uppercase tracking-wider text-text-tertiary mb-2">Tips for refining your query</h3>
            <p className="text-xs text-text-secondary">• Use broader terms or fewer keywords</p>
            <p className="text-xs text-text-secondary">• Try synonyms or related concepts</p>
            <p className="text-xs text-text-secondary">• Remove strict filters (peer-reviewed, indexed only)</p>
            <p className="text-xs text-text-secondary">• Use "exact phrase" with quotes for precise matching</p>
            <p className="text-xs text-text-secondary">• Expand the date range to include more years</p>
            <p className="text-xs text-text-secondary">• Enable additional sources in the parameters panel</p>
          </div>
        </div>
      </div>
    );
  }

  if (state === 'error') {
    return (
      <div className="flex flex-col items-center justify-center py-20 px-4 animate-fade-in">
        <div className="max-w-md text-center">
          <div className="w-14 h-14 mx-auto mb-5 rounded-2xl bg-danger-muted/30 flex items-center justify-center">
            <AlertCircle className="w-7 h-7 text-danger" />
          </div>
          <h2 className="text-lg font-semibold text-text-primary mb-2">Search failed</h2>
          <p className="text-sm text-text-secondary mb-6 leading-relaxed">
            An error occurred while searching. This could be a network issue or a temporary service outage.
          </p>
          <button
            onClick={onRetry}
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-accent hover:bg-accent-muted text-white text-sm font-medium rounded-lg transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
            Retry search
          </button>
        </div>
      </div>
    );
  }

  if (state === 'partial') {
    return (
      <div className="flex flex-col items-center justify-center py-20 px-4 animate-fade-in">
        <div className="max-w-md text-center">
          <div className="w-14 h-14 mx-auto mb-5 rounded-2xl bg-warning-muted/30 flex items-center justify-center">
            <AlertCircle className="w-7 h-7 text-warning" />
          </div>
          <h2 className="text-lg font-semibold text-text-primary mb-2">Partial results</h2>
          <p className="text-sm text-text-secondary mb-4 leading-relaxed">
            Some sources could not be reached. Results shown are from available sources only.
          </p>
          <div className="bg-bg-card border border-border-default rounded-lg p-4 mb-5">
            <h3 className="text-[11px] uppercase tracking-wider text-text-tertiary mb-2">Unavailable sources</h3>
            {sourcesFailed.map((s) => (
              <p key={s} className="text-xs text-warning">• {s}</p>
            ))}
          </div>
          <button
            onClick={onRetry}
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-accent hover:bg-accent-muted text-white text-sm font-medium rounded-lg transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
            Retry all sources
          </button>
        </div>
      </div>
    );
  }

  return null;
}
