import { useState, useRef, useEffect } from 'react';
import { ChevronDown, X, Filter, Check } from 'lucide-react';
import { Filters, ALL_SOURCES } from '../types';

interface FilterPanelProps {
  filters: Filters;
  onFiltersChange: (f: Filters) => void;
  isMobileOpen: boolean;
  onMobileClose: () => void;
}

function SelectDropdown({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: string;
  options: { value: string; label: string }[];
  onChange: (v: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const current = options.find(o => o.value === value);

  return (
    <div ref={ref} className="relative">
      <label className="block text-[11px] uppercase tracking-wider text-text-tertiary mb-1.5">{label}</label>
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between bg-bg-input border border-border-default rounded-lg px-3 py-2 text-sm text-text-primary hover:border-accent/30 transition-colors"
      >
        <span>{current?.label}</span>
        <ChevronDown className={`w-4 h-4 text-text-tertiary transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-bg-elevated border border-border-default rounded-lg shadow-xl z-50 overflow-hidden">
          {options.map((opt) => (
            <button
              key={opt.value}
              onClick={() => { onChange(opt.value); setOpen(false); }}
              className={`w-full text-left px-3 py-2 text-sm hover:bg-bg-hover transition-colors ${
                opt.value === value ? 'text-accent bg-accent-subtle/30' : 'text-text-secondary'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function CheckboxItem({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <div
      onClick={() => onChange(!checked)}
      className="flex items-center gap-2.5 cursor-pointer group py-1"
    >
      <div className={`w-4 h-4 rounded border flex items-center justify-center transition-colors shrink-0 ${
        checked ? 'bg-accent border-accent' : 'border-border-default group-hover:border-text-tertiary'
      }`}>
        {checked && <Check className="w-3 h-3 text-white" />}
      </div>
      <span className="text-sm text-text-secondary group-hover:text-text-primary transition-colors select-none">{label}</span>
    </div>
  );
}

export function FilterPanel({ filters, onFiltersChange, isMobileOpen, onMobileClose }: FilterPanelProps) {
  const [sourcesOpen, setSourcesOpen] = useState(false);
  const sourcesRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (sourcesRef.current && !sourcesRef.current.contains(e.target as Node)) setSourcesOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const updateFilter = <K extends keyof Filters>(key: K, value: Filters[K]) => {
    onFiltersChange({ ...filters, [key]: value });
  };

  const selectAllSources = () => onFiltersChange({ ...filters, sources: [...ALL_SOURCES] });
  const clearAllSources = () => onFiltersChange({ ...filters, sources: [] });

  const content = (
    <div className="space-y-6">
      {/* Language */}
      <SelectDropdown
        label="UI Language"
        value={filters.language}
        options={[{ value: 'en', label: 'English' }, { value: 'ru', label: 'Русский' }]}
        onChange={(v) => updateFilter('language', v as 'en' | 'ru')}
      />

      {/* Citation style */}
      <SelectDropdown
        label="Citation Style"
        value={filters.citationStyle}
        options={[{ value: 'gost2018', label: 'GOST R 7.0.100-2018' }, { value: 'gost2003', label: 'GOST 7.1-2003' }]}
        onChange={(v) => updateFilter('citationStyle', v as 'gost2018' | 'gost2003')}
      />

      {/* Sources */}
      <div ref={sourcesRef}>
        <label className="block text-[11px] uppercase tracking-wider text-text-tertiary mb-1.5">Sources</label>
        <button
          onClick={() => setSourcesOpen(!sourcesOpen)}
          className="w-full flex items-center justify-between bg-bg-input border border-border-default rounded-lg px-3 py-2 text-sm text-text-primary hover:border-accent/30 transition-colors"
        >
          <span>{filters.sources.length} of {ALL_SOURCES.length} selected</span>
          <ChevronDown className={`w-4 h-4 text-text-tertiary transition-transform ${sourcesOpen ? 'rotate-180' : ''}`} />
        </button>
        {sourcesOpen && (
          <div className="mt-1 bg-bg-elevated border border-border-default rounded-lg shadow-xl z-50 max-h-64 overflow-y-auto">
            <div className="sticky top-0 bg-bg-elevated flex gap-2 p-2 border-b border-border-default">
              <button onClick={selectAllSources} className="text-[11px] text-accent hover:text-accent-muted px-2 py-0.5">Select all</button>
              <button onClick={clearAllSources} className="text-[11px] text-text-tertiary hover:text-text-secondary px-2 py-0.5">Clear</button>
            </div>
            {ALL_SOURCES.map((source) => (
              <label key={source} className="flex items-center gap-2.5 px-3 py-1.5 hover:bg-bg-hover cursor-pointer">
                <div className={`w-3.5 h-3.5 rounded border flex items-center justify-center transition-colors shrink-0 ${
                  filters.sources.includes(source) ? 'bg-accent border-accent' : 'border-border-default'
                }`}>
                  {filters.sources.includes(source) && <Check className="w-2.5 h-2.5 text-white" />}
                </div>
                <span className="text-xs text-text-secondary">{source}</span>
              </label>
            ))}
          </div>
        )}
      </div>

      {/* Strict filters */}
      <div>
        <label className="block text-[11px] uppercase tracking-wider text-text-tertiary mb-2.5">Strict Filters</label>
        <div className="space-y-0.5">
          <CheckboxItem
            label="DOI only"
            checked={filters.doiOnly}
            onChange={(v) => updateFilter('doiOnly', v)}
          />
          <CheckboxItem
            label="Peer-reviewed / refereed only"
            checked={filters.peerReviewedOnly}
            onChange={(v) => updateFilter('peerReviewedOnly', v)}
          />
          <CheckboxItem
            label="Indexed only (Scopus / WoS)"
            checked={filters.indexedOnly}
            onChange={(v) => updateFilter('indexedOnly', v)}
          />
          <CheckboxItem
            label="Exclude preprints & manuscripts"
            checked={filters.excludePreprints}
            onChange={(v) => updateFilter('excludePreprints', v)}
          />
        </div>
      </div>

      {/* Date range */}
      <div>
        <label className="block text-[11px] uppercase tracking-wider text-text-tertiary mb-1.5">Date Range</label>
        <div className="flex items-center gap-2">
          <input
            type="number"
            placeholder="From"
            value={filters.dateFrom}
            onChange={(e) => updateFilter('dateFrom', e.target.value)}
            className="w-full bg-bg-input border border-border-default rounded-lg px-3 py-2 text-sm text-text-primary placeholder:text-text-tertiary focus:outline-none focus:border-accent/50 transition-colors"
            min="1900"
            max="2026"
          />
          <span className="text-text-tertiary text-sm shrink-0">—</span>
          <input
            type="number"
            placeholder="To"
            value={filters.dateTo}
            onChange={(e) => updateFilter('dateTo', e.target.value)}
            className="w-full bg-bg-input border border-border-default rounded-lg px-3 py-2 text-sm text-text-primary placeholder:text-text-tertiary focus:outline-none focus:border-accent/50 transition-colors"
            min="1900"
            max="2026"
          />
        </div>
      </div>

      {/* Sort */}
      <SelectDropdown
        label="Sort By"
        value={filters.sortBy}
        options={[
          { value: 'relevance', label: 'Relevance' },
          { value: 'newest', label: 'Newest first' },
          { value: 'metadata', label: 'Metadata completeness' },
        ]}
        onChange={(v) => updateFilter('sortBy', v as 'relevance' | 'newest' | 'metadata')}
      />
    </div>
  );

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="hidden lg:block w-[280px] shrink-0">
        <div className="sticky top-[160px] bg-bg-card border border-border-default rounded-xl p-5">
          <div className="flex items-center gap-2 mb-5">
            <Filter className="w-4 h-4 text-text-tertiary" />
            <h2 className="text-sm font-medium text-text-primary">Parameters</h2>
          </div>
          {content}
        </div>
      </aside>

      {/* Mobile drawer */}
      {isMobileOpen && (
        <div className="fixed inset-0 z-[60] lg:hidden">
          <div className="absolute inset-0 bg-black/60" onClick={onMobileClose} />
          <div className="absolute left-0 top-0 bottom-0 w-[320px] max-w-[85vw] bg-bg-primary border-r border-border-default overflow-y-auto animate-slide-in-left">
            <div className="p-5">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-2">
                  <Filter className="w-4 h-4 text-text-tertiary" />
                  <h2 className="text-sm font-medium text-text-primary">Parameters</h2>
                </div>
                <button onClick={onMobileClose} className="p-1 text-text-tertiary hover:text-text-primary">
                  <X className="w-5 h-5" />
                </button>
              </div>
              {content}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
