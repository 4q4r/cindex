import { BookOpen, Clock, Radio } from 'lucide-react';
import { SearchState } from '../types';

interface HeaderProps {
  resultCount: number;
  lastSearchTime: Date | null;
  sourcesQueried: number;
  sourcesFailed: string[];
  searchState: SearchState;
}

export function Header({ resultCount, lastSearchTime, sourcesQueried, sourcesFailed, searchState }: HeaderProps) {
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };

  const activeSources = sourcesQueried - sourcesFailed.length;

  return (
    <header className="border-b border-border-default bg-bg-primary/80 backdrop-blur-sm sticky top-0 z-50">
      <div className="max-w-[1440px] mx-auto px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-accent" />
            <h1 className="text-lg font-semibold tracking-tight text-text-primary">
              CIndex
            </h1>
          </div>
          <span className="text-xs text-text-tertiary border-l border-border-default pl-3">
            Citation source search
          </span>
        </div>

        <div className="flex items-center gap-5 text-xs text-text-secondary">
          {searchState !== 'idle' && (
            <>
              <div className="flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5" />
                <span>
                  {resultCount} result{resultCount !== 1 ? 's' : ''} found
                </span>
              </div>

              {lastSearchTime && (
                <div className="flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Searched at {formatTime(lastSearchTime)}</span>
                </div>
              )}

              <div className="flex items-center gap-1.5">
                <Radio className="w-3.5 h-3.5" />
                <span className={sourcesFailed.length > 0 ? 'text-warning' : 'text-success'}>
                  {activeSources}/{sourcesQueried} sources, {sourcesFailed.length > 0 ? 'partial' : 'live'}
                </span>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
