import { AlertTriangle, X, SlidersHorizontal } from 'lucide-react';

interface InfoBarProps {
  totalResults: number;
  filteredOut: number;
  sourcesFailed: string[];
  onClearFilters: () => void;
  onToggleMobileFilters: () => void;
  viewMode: 'compact' | 'comfortable';
  onViewModeChange: (m: 'compact' | 'comfortable') => void;
  hasActiveFilters: boolean;
}

export function InfoBar({
  totalResults,
  filteredOut,
  sourcesFailed,
  onClearFilters,
  onToggleMobileFilters,
  viewMode,
  onViewModeChange,
  hasActiveFilters,
}: InfoBarProps) {
  return (
    <div className="flex items-center justify-between gap-4 flex-wrap">
      <div className="flex items-center gap-3 flex-wrap">
        <span className="text-sm text-text-secondary">
          <span className="text-text-primary font-medium">{totalResults}</span> result{totalResults !== 1 ? 's' : ''} found
        </span>

        {filteredOut > 0 && (
          <span className="text-xs text-text-tertiary">
            ({filteredOut} filtered out by strict criteria)
          </span>
        )}

        {sourcesFailed.length > 0 && (
          <div className="flex items-center gap-1.5 text-xs text-warning">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Sources unavailable: {sourcesFailed.join(', ')}</span>
          </div>
        )}

        {hasActiveFilters && (
          <button
            onClick={onClearFilters}
            className="flex items-center gap-1 text-xs text-accent hover:text-accent-muted transition-colors"
          >
            <X className="w-3 h-3" />
            Clear filters
          </button>
        )}
      </div>

      <div className="flex items-center gap-3">
        {/* Mobile filter toggle */}
        <button
          onClick={onToggleMobileFilters}
          className="lg:hidden flex items-center gap-1.5 text-xs text-text-secondary hover:text-text-primary bg-bg-elevated border border-border-default px-3 py-1.5 rounded-lg transition-colors"
        >
          <SlidersHorizontal className="w-3.5 h-3.5" />
          Filters
          {hasActiveFilters && (
            <span className="w-1.5 h-1.5 rounded-full bg-accent" />
          )}
        </button>

        {/* View mode toggle */}
        <div className="flex items-center bg-bg-elevated border border-border-default rounded-lg overflow-hidden">
          <button
            onClick={() => onViewModeChange('comfortable')}
            className={`px-3 py-1.5 text-xs transition-colors ${
              viewMode === 'comfortable' ? 'bg-accent/15 text-accent' : 'text-text-tertiary hover:text-text-secondary'
            }`}
          >
            Comfortable
          </button>
          <button
            onClick={() => onViewModeChange('compact')}
            className={`px-3 py-1.5 text-xs transition-colors ${
              viewMode === 'compact' ? 'bg-accent/15 text-accent' : 'text-text-tertiary hover:text-text-secondary'
            }`}
          >
            Compact
          </button>
        </div>
      </div>
    </div>
  );
}
