import { useState, useEffect } from 'react';

interface LoadingStateProps {
  sourcesQueried: number;
}

export function LoadingState({ sourcesQueried }: LoadingStateProps) {
  const [progress, setProgress] = useState(0);
  const [currentSource, setCurrentSource] = useState('');

  const sourceList = [
    'CrossRef', 'Semantic Scholar', 'OpenAlex', 'PubMed', 'eLibrary.ru',
    'Google Scholar', 'Scopus', 'Web of Science', 'DOAJ', 'arXiv',
    'bioRxiv', 'CyberLeninka', 'Dryad', 'JSTOR', 'PubMed Central',
    'SciELO', 'Springer Nature', 'Elsevier ScienceDirect', 'Wiley Online',
    'IEEE Xplore', 'Taylor & Francis', 'SAGE Journals', 'De Gruyter',
  ];

  useEffect(() => {
    let frame: number;
    let elapsed = 0;
    const interval = 80;
    const step = () => {
      elapsed += interval;
      const idx = Math.min(Math.floor(elapsed / 100), sourceList.length - 1);
      setCurrentSource(sourceList[idx]);
      setProgress(Math.min(((elapsed / 2500) * 100), 95));
      if (elapsed < 2500) {
        frame = window.setTimeout(step, interval);
      }
    };
    frame = window.setTimeout(step, interval);
    return () => clearTimeout(frame);
  }, []);

  return (
    <div className="animate-fade-in">
      {/* Progress bar */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs text-text-secondary">
            Scanning {currentSource}...
          </span>
          <span className="text-xs text-text-tertiary">
            {Math.round(progress)}% · {sourcesQueried} sources
          </span>
        </div>
        <div className="w-full h-1 bg-bg-elevated rounded-full overflow-hidden">
          <div
            className="h-full bg-accent rounded-full transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {/* Skeleton cards */}
      <div className="space-y-4">
        {[0, 1, 2].map((i) => (
          <div key={i} className="bg-bg-card border border-border-default rounded-xl p-6">
            <div className="flex items-start justify-between mb-3">
              <div className="flex-1">
                <div className="skeleton h-5 w-full max-w-lg mb-2" />
                <div className="skeleton h-5 w-3/4 max-w-md" />
              </div>
              <div className="skeleton h-5 w-20 shrink-0 ml-3" />
            </div>
            <div className="skeleton h-4 w-80 mb-3" />
            <div className="flex gap-2 mb-4">
              <div className="skeleton h-5 w-16" />
              <div className="skeleton h-5 w-24" />
              <div className="skeleton h-5 w-20" />
              <div className="skeleton h-5 w-24" />
            </div>
            <div className="space-y-2 mb-4">
              <div className="skeleton h-3.5 w-full" />
              <div className="skeleton h-3.5 w-full" />
              <div className="skeleton h-3.5 w-5/6" />
              <div className="skeleton h-3.5 w-4/5" />
              <div className="skeleton h-3.5 w-full" />
            </div>
            <div className="flex gap-2">
              <div className="skeleton h-7 w-24" />
              <div className="skeleton h-7 w-24" />
              <div className="skeleton h-7 w-28" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
