import { useState, useMemo } from 'react';
import {
  Copy, ExternalLink, ChevronDown, ChevronUp, Bookmark,
  CheckCircle2, XCircle, Shield, Database, Hash, FileText,
  Clock, Tag, Zap, Search as SearchIcon,
} from 'lucide-react';
import { SearchResult, ViewMode, Filters } from '../types';

interface ResultCardProps {
  result: SearchResult;
  query: string;
  viewMode: ViewMode;
  citationStyle: Filters['citationStyle'];
  onCopy: (text: string, type: string) => void;
}

function HighlightedText({ text, query }: { text: string; query: string }) {
  const parts = useMemo(() => {
    if (!query.trim()) return [text];
    const words = query.split(/\s+/).filter(w => w.length > 1);
    if (words.length === 0) return [text];

    const regex = new RegExp(`(${words.map(w => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|')})`, 'gi');
    const segments = text.split(regex);
    return segments;
  }, [text, query]);

  return (
    <>
      {parts.map((part, i) => {
        const isMatch = query.trim() && parts.length > 1 && i % 2 === 1;
        return isMatch ? (
          <span key={i} className="highlight-match">{part}</span>
        ) : (
          <span key={i}>{part}</span>
        );
      })}
    </>
  );
}

function CriterionBadge({ label, value, icon: Icon }: { label: string; value: boolean; icon: React.ElementType }) {
  return (
    <div className={`flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-medium ${
      value
        ? 'bg-success-muted/40 text-success'
        : 'bg-bg-elevated text-text-tertiary'
    }`}>
      <Icon className="w-3 h-3" />
      <span>{label}</span>
      {value ? <CheckCircle2 className="w-3 h-3" /> : <XCircle className="w-3 h-3 opacity-50" />}
    </div>
  );
}

function ConfidenceBadge({ score }: { score: number }) {
  let level: 'high' | 'medium' | 'low';
  let color: string;
  if (score >= 75) { level = 'high'; color = 'bg-success-muted/40 text-success'; }
  else if (score >= 50) { level = 'medium'; color = 'bg-warning-muted/40 text-warning'; }
  else { level = 'low'; color = 'bg-danger-muted/40 text-danger'; }

  return (
    <div className={`flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium ${color}`}>
      <Zap className="w-3 h-3" />
      <span>{level.charAt(0).toUpperCase() + level.slice(1)} relevance</span>
    </div>
  );
}

function SearchModeBadge({ mode }: { mode: string }) {
  const labels: Record<string, string> = { text: 'Text search', vector: 'Vector search', hybrid: 'Hybrid search' };
  return (
    <div className="flex items-center gap-1 px-2 py-0.5 rounded text-[11px] text-text-tertiary bg-bg-elevated">
      <SearchIcon className="w-3 h-3" />
      <span>{labels[mode] || mode}</span>
    </div>
  );
}

function EvidenceSection({ result }: { result: SearchResult }) {
  const evidenceItems = [
    {
      label: 'Peer-reviewed confirmation',
      icon: Shield,
      value: result.isPeerReviewed,
      evidence: result.peerReviewEvidence,
    },
    {
      label: 'Indexing confirmation',
      icon: Database,
      value: result.isIndexed,
      evidence: result.indexingEvidence,
    },
    {
      label: 'DOI / journal record',
      icon: Hash,
      value: result.hasDoi,
      evidence: result.doiEvidence,
    },
    {
      label: 'Preprint status',
      icon: FileText,
      value: !result.isPreprint,
      evidence: result.preprintEvidence,
      passLabel: 'Not a preprint',
      failLabel: 'This is a preprint',
    },
  ];

  return (
    <div className="mt-4 pt-4 border-t border-border-subtle space-y-3">
      <h4 className="text-[11px] uppercase tracking-wider text-text-tertiary font-medium">Evidence & Provenance</h4>
      {evidenceItems.map((item) => (
        <div key={item.label} className="flex items-start gap-3">
          <div className={`mt-0.5 shrink-0 ${item.value ? 'text-success' : 'text-text-tertiary'}`}>
            <item.icon className="w-4 h-4" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-xs font-medium text-text-primary">
                {item.label}
              </span>
              <span className={`text-[11px] ${item.value ? 'text-success' : 'text-warning'}`}>
                {item.value
                  ? (item.passLabel || 'Confirmed')
                  : (item.failLabel || 'Not confirmed')}
              </span>
            </div>
            <p className="text-[11px] text-text-tertiary mt-0.5 leading-relaxed">
              {item.evidence || 'No data available'}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
}

export function ResultCard({ result, query, viewMode, citationStyle, onCopy }: ResultCardProps) {
  const [expanded, setExpanded] = useState(false);
  const [showCitation, setShowCitation] = useState(false);

  const isCompact = viewMode === 'compact';
  const citation = citationStyle === 'gost2018' ? result.citationGost2018 : result.citationGost2003;

  const identifiers = [
    result.doi && { label: 'DOI', value: result.doi },
    result.pmid && { label: 'PMID', value: result.pmid },
    result.pmcid && { label: 'PMCID', value: result.pmcid },
    result.issn && { label: 'ISSN', value: result.issn },
  ].filter(Boolean) as { label: string; value: string }[];

  return (
    <article
      className={`bg-bg-card border border-border-default rounded-xl transition-colors hover:border-border-default/80 animate-fade-in ${
        isCompact ? 'p-4' : 'p-6'
      }`}
    >
      {/* Top row: metadata + badges */}
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex-1 min-w-0">
          <h3 className="text-[15px] font-medium text-text-primary leading-snug hover:text-accent transition-colors cursor-pointer">
            <HighlightedText text={result.title} query={query} />
          </h3>
        </div>
        <ConfidenceBadge score={result.relevanceScore} />
      </div>

      {/* Authors, year, journal */}
      <div className={`text-sm text-text-secondary ${isCompact ? 'mb-2' : 'mb-3'} leading-relaxed`}>
        <span>{result.authors.join(', ')}</span>
        <span className="text-text-tertiary"> · </span>
        <span className="text-text-primary font-medium">{result.year}</span>
        <span className="text-text-tertiary"> · </span>
        <span className="italic">{result.journal}</span>
        <span className="text-text-tertiary"> · </span>
        <span className="text-accent/70 text-xs">{result.source}</span>
      </div>

      {/* Identifiers */}
      {identifiers.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-3">
          {identifiers.map((id) => (
            <span key={id.label} className="text-[11px] text-text-tertiary bg-bg-elevated px-2 py-0.5 rounded">
              {id.label}: <span className="text-text-secondary font-mono">{id.value}</span>
            </span>
          ))}
        </div>
      )}

      {/* Criterion badges */}
      <div className="flex flex-wrap gap-1.5 mb-4">
        <CriterionBadge label="DOI" value={result.hasDoi} icon={Hash} />
        <CriterionBadge label="Peer-reviewed" value={result.isPeerReviewed} icon={Shield} />
        <CriterionBadge label="Indexed" value={result.isIndexed} icon={Database} />
        <CriterionBadge label="Not preprint" value={!result.isPreprint} icon={FileText} />
        <SearchModeBadge mode={result.searchMode} />
      </div>

      {/* Snippet */}
      <div className={`text-sm text-text-secondary leading-relaxed ${isCompact ? 'line-clamp-4' : ''} mb-4`}>
        <HighlightedText text={result.snippet} query={query} />
      </div>

      {/* Citation toggle */}
      <div className="mb-3">
        <button
          onClick={() => setShowCitation(!showCitation)}
          className="text-[11px] uppercase tracking-wider text-text-tertiary hover:text-text-secondary flex items-center gap-1 transition-colors"
        >
          {showCitation ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
          {citationStyle === 'gost2018' ? 'GOST R 7.0.100-2018' : 'GOST 7.1-2003'} Citation
        </button>
        {showCitation && (
          <div className="mt-2 bg-bg-elevated border border-border-subtle rounded-lg p-3 text-xs text-text-secondary leading-relaxed font-mono">
            {citation}
          </div>
        )}
      </div>

      {/* Actions */}
      <div className="flex items-center gap-2 flex-wrap">
        <button
          onClick={() => onCopy(citation, 'citation')}
          className="flex items-center gap-1.5 text-xs text-text-tertiary hover:text-accent bg-bg-elevated border border-border-default px-3 py-1.5 rounded-lg transition-colors"
        >
          <Copy className="w-3.5 h-3.5" />
          Copy citation
        </button>
        <button
          onClick={() => onCopy(result.snippet, 'snippet')}
          className="flex items-center gap-1.5 text-xs text-text-tertiary hover:text-accent bg-bg-elevated border border-border-default px-3 py-1.5 rounded-lg transition-colors"
        >
          <Copy className="w-3.5 h-3.5" />
          Copy snippet
        </button>
        {result.doi && (
          <a
            href={`https://doi.org/${result.doi}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 text-xs text-text-tertiary hover:text-accent bg-bg-elevated border border-border-default px-3 py-1.5 rounded-lg transition-colors"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            Open source
          </a>
        )}
        <button
          className="flex items-center gap-1.5 text-xs text-text-tertiary hover:text-accent bg-bg-elevated border border-border-default px-3 py-1.5 rounded-lg transition-colors"
          onClick={() => {}}
        >
          <Bookmark className="w-3.5 h-3.5" />
          Save
        </button>
      </div>

      {/* Technical transparency */}
      <div className="flex items-center gap-4 mt-3 text-[11px] text-text-tertiary">
        <div className="flex items-center gap-1">
          <Clock className="w-3 h-3" />
          <span>Indexed: {new Date(result.indexedDate).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })}</span>
        </div>
        <div className="flex items-center gap-1">
          <Tag className="w-3 h-3" />
          <span>Snippet from: {result.snippetSource}</span>
        </div>
      </div>

      {/* Evidence panel toggle */}
      <button
        onClick={() => setExpanded(!expanded)}
        className="mt-3 text-[11px] uppercase tracking-wider text-text-tertiary hover:text-text-secondary flex items-center gap-1 transition-colors"
      >
        {expanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
        {expanded ? 'Hide' : 'Show'} evidence details
      </button>
      {expanded && <EvidenceSection result={result} />}
    </article>
  );
}
