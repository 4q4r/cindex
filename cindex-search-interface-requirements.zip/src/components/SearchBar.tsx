import { Search, X } from 'lucide-react';

interface SearchBarProps {
  query: string;
  onQueryChange: (q: string) => void;
  onSearch: () => void;
  isLoading: boolean;
}

const quickQueries = [
  'machine learning diagnosis',
  'CRISPR gene editing',
  'climate change biodiversity',
  'quantum error correction',
  'antibiotic resistance',
  'dark matter detection',
];

export function SearchBar({ query, onQueryChange, onSearch, isLoading }: SearchBarProps) {
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !isLoading) {
      onSearch();
    }
  };

  return (
    <div className="sticky top-[53px] z-40 bg-bg-primary/90 backdrop-blur-sm border-b border-border-subtle">
      <div className="max-w-[1440px] mx-auto px-6 py-5">
        <div className="max-w-3xl mx-auto">
          {/* Search input */}
          <div className="relative flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-text-tertiary" />
              <input
                type="text"
                value={query}
                onChange={(e) => onQueryChange(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Search articles, authors, topics, DOI..."
                className="w-full bg-bg-input border border-border-default rounded-lg pl-12 pr-10 py-3.5 text-text-primary placeholder:text-text-tertiary focus:outline-none focus:border-accent/50 focus:ring-1 focus:ring-accent/20 transition-colors text-[15px]"
                disabled={isLoading}
              />
              {query && (
                <button
                  onClick={() => onQueryChange('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-text-tertiary hover:text-text-secondary transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
            <button
              onClick={onSearch}
              disabled={isLoading || !query.trim()}
              className="px-6 py-3.5 bg-accent hover:bg-accent-muted disabled:opacity-40 disabled:cursor-not-allowed text-white font-medium rounded-lg transition-colors text-sm shrink-0"
            >
              {isLoading ? (
                <span className="flex items-center gap-2">
                  <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                  </svg>
                  Searching...
                </span>
              ) : 'Search'}
            </button>
          </div>

          {/* Syntax hints */}
          <div className="flex items-center gap-4 mt-2.5 text-[11px] text-text-tertiary">
            <span>"exact phrase" for precise matching</span>
            <span className="text-border-default">|</span>
            <span>AND / OR for boolean logic</span>
            <span className="text-border-default">|</span>
            <span>-term to exclude</span>
          </div>

          {/* Quick query chips */}
          <div className="flex flex-wrap items-center gap-2 mt-3.5">
            <span className="text-[11px] text-text-tertiary uppercase tracking-wider mr-1">Try:</span>
            {quickQueries.map((q) => (
              <button
                key={q}
                onClick={() => {
                  onQueryChange(q);
                }}
                className="px-3 py-1 text-xs text-text-secondary bg-bg-elevated border border-border-default rounded-full hover:bg-bg-hover hover:text-text-primary hover:border-accent/30 transition-all"
              >
                {q}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
