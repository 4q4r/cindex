export interface SearchResult {
  id: string;
  title: string;
  titleRu?: string;
  authors: string[];
  year: number;
  journal: string;
  publisher: string;
  source: string;
  doi?: string;
  pmid?: string;
  pmcid?: string;
  issn?: string;
  isPeerReviewed: boolean;
  isIndexed: boolean;
  hasDoi: boolean;
  isPreprint: boolean;
  peerReviewEvidence: string;
  indexingEvidence: string;
  doiEvidence: string;
  preprintEvidence: string;
  snippet: string;
  citationGost2018: string;
  citationGost2003: string;
  indexedDate: string;
  snippetSource: string;
  relevanceScore: number;
  searchMode: 'text' | 'vector' | 'hybrid';
}

export interface Filters {
  language: 'en' | 'ru';
  citationStyle: 'gost2018' | 'gost2003';
  sources: string[];
  doiOnly: boolean;
  peerReviewedOnly: boolean;
  indexedOnly: boolean;
  excludePreprints: boolean;
  dateFrom: string;
  dateTo: string;
  sortBy: 'relevance' | 'newest' | 'metadata';
}

export type SearchState = 'idle' | 'loading' | 'results' | 'empty' | 'error' | 'partial';
export type ViewMode = 'compact' | 'comfortable';

export const ALL_SOURCES = [
  'CrossRef',
  'Semantic Scholar',
  'OpenAlex',
  'PubMed',
  'eLibrary.ru',
  'Google Scholar',
  'Scopus',
  'Web of Science',
  'DOAJ',
  'arXiv',
  'bioRxiv',
  'CyberLeninka',
  'Dryad',
  'JSTOR',
  'PubMed Central',
  'SciELO',
  'Springer Nature',
  'Elsevier ScienceDirect',
  'Wiley Online',
  'IEEE Xplore',
  'Taylor & Francis',
  'SAGE Journals',
  'De Gruyter',
] as const;

export const DEFAULT_FILTERS: Filters = {
  language: 'en',
  citationStyle: 'gost2018',
  sources: [...ALL_SOURCES],
  doiOnly: false,
  peerReviewedOnly: false,
  indexedOnly: false,
  excludePreprints: false,
  dateFrom: '',
  dateTo: '',
  sortBy: 'relevance',
};
